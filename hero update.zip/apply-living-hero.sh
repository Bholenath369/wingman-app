#!/bin/bash
# Wingman Living Hero — turn the static brain image into a breathing, animated moment
# Run from project root:  bash apply-living-hero.sh

set -e

echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║   Living Hero — Sparks, Particles, Scan Reveal    ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

[ ! -f "package.json" ] && echo "❌ Run from project root." && exit 1
[ ! -f "wingman-living-hero.zip" ] && echo "❌ wingman-living-hero.zip not found here." && exit 1

# Check prerequisites from previous upgrades
if [ ! -f "public/images/hero-analyze.jpg" ]; then
  echo "⚠️  public/images/hero-analyze.jpg not found."
  echo "   You need to run the hero-upgrade step first."
  echo "   This upgrade animates the brain images from that step."
  exit 1
fi

if [ ! -f "src/components/Hero.jsx" ]; then
  echo "⚠️  src/components/Hero.jsx not found."
  echo "   Run apply-hero-upgrade.sh first."
  exit 1
fi

# Backup
BACKUP=".backup-livinghero-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP/src/components"
cp src/components/Hero.jsx          "$BACKUP/src/components/" 2>/dev/null || true
cp src/index.css                     "$BACKUP/src/" 2>/dev/null || true
cp src/screens/AnalyzeScreen.jsx     "$BACKUP/src/screens/" 2>/dev/null || true
cp src/screens/PersonalityScreen.jsx "$BACKUP/src/screens/" 2>/dev/null || true
cp src/screens/CoachScreen.jsx       "$BACKUP/src/screens/" 2>/dev/null || true
cp src/screens/SimulateScreen.jsx    "$BACKUP/src/screens/" 2>/dev/null || true
cp src/screens/ProfileScreen.jsx     "$BACKUP/src/screens/" 2>/dev/null || true
echo "✓ Backup: $BACKUP"
echo ""

# Extract
rm -rf .tmp-livinghero
unzip -q -o wingman-living-hero.zip -d .tmp-livinghero
SRC=".tmp-livinghero/hero-fx"
[ ! -d "$SRC" ] && echo "❌ Zip structure wrong." && exit 1
echo "✓ Extracted"
echo ""

# Install components
echo "→ Installing living hero components..."
cp "$SRC/src/components/HeroCanvas.jsx" src/components/HeroCanvas.jsx && echo "  ✓ HeroCanvas.jsx (animated particles + sparks)"
cp "$SRC/src/components/Hero.jsx"       src/components/Hero.jsx       && echo "  ✓ Hero.jsx (updated with canvas layer)"
echo ""

# Append CSS
echo "→ Appending living hero CSS..."
if grep -q "Living Hero Effects" src/index.css; then
  echo "  ⚠️  Living hero CSS already present — skipping"
else
  echo "" >> src/index.css
  cat "$SRC/src/index-additions-living-hero.css" >> src/index.css
  echo "  ✓ CSS appended"
fi
echo ""

# Patch each screen to use the Hero component instead of the raw hero JSX
echo "→ Refactoring screens to use <Hero /> component..."

patch_screen_to_hero() {
  local file=$1
  local image_name=$2
  local variant=$3
  if [ ! -f "$file" ]; then
    echo "  ⚠️  $file not found — skipping"
    return
  fi

  node -e "
    const fs = require('fs');
    const path = '$file';
    const imageName = '$image_name';
    const variant = '$variant';
    let content = fs.readFileSync(path, 'utf8');

    // Check if Hero is already imported
    if (!content.includes(\"import Hero from\") && !content.includes('import Hero ')) {
      // Add import after the last import line
      const importMatch = content.match(/^(import[^;]+;\\s*\\n)+/m);
      if (importMatch) {
        const lastImportEnd = importMatch.index + importMatch[0].length;
        content = content.slice(0, lastImportEnd) +
          'import Hero from \"../components/Hero\";\\n' +
          content.slice(lastImportEnd);
      }
    }

    // Now find the hero block. Patterns to match:
    // Pattern A (has <picture> already from previous upgrade):
    //   <div className=\"hero hero-with-image\">...<picture>...</picture>...<div className=\"hero-content\">...HEADING...DESC...</div></div>
    // Pattern B (simple img):
    //   <div className=\"hero hero-with-image\">...<img .../>...<div className=\"hero-content\">...</div></div>

    // Robust approach: find the full hero block and replace it
    // Match the opening div and scan for its matching closing div
    const heroStartPatterns = [
      /<div className=\"hero hero-with-image\"[^>]*>/,
    ];

    let replaced = false;

    for (const startPat of heroStartPatterns) {
      const m = content.match(startPat);
      if (!m) continue;
      const startIdx = m.index;

      // Find matching close tag by counting divs
      let depth = 0;
      let i = startIdx;
      let endIdx = -1;
      const re = /<\\/?div\\b[^>]*>/g;
      re.lastIndex = startIdx;
      let match;
      while ((match = re.exec(content)) !== null) {
        if (match[0].startsWith('</')) {
          depth--;
          if (depth === 0) {
            endIdx = match.index + match[0].length;
            break;
          }
        } else {
          depth++;
        }
      }

      if (endIdx === -1) continue;

      // Extract eyebrow, title, description from the block
      const block = content.slice(startIdx, endIdx);
      const eyebrowMatch = block.match(/<div className=\"hero-eyebrow\"[^>]*>([^<]+)<\\/div>/);
      const titleMatch   = block.match(/<h2[^>]*>([^<]+)<\\/h2>/);
      const descMatch    = block.match(/<p[^>]*>([^<]+)<\\/p>/);

      if (!titleMatch) continue;

      const eyebrow = eyebrowMatch ? eyebrowMatch[1].trim() : '';
      const title   = titleMatch[1].trim();
      const desc    = descMatch ? descMatch[1].trim() : '';

      // Build Hero component JSX
      const heroJsx = '<Hero\\n' +
        '        image=\"' + imageName + '\"\\n' +
        (variant ? '        variant=\"' + variant + '\"\\n' : '') +
        (eyebrow ? '        eyebrow={\"' + eyebrow.replace(/\"/g, '\\\\\"') + '\"}\\n' : '') +
        '        title=\"' + title.replace(/\"/g, '\\\\\"') + '\"\\n' +
        (desc ? '        description=\"' + desc.replace(/\"/g, '\\\\\"') + '\"\\n' : '') +
        '      />';

      content = content.slice(0, startIdx) + heroJsx + content.slice(endIdx);
      replaced = true;
      break;
    }

    if (replaced) {
      fs.writeFileSync(path, content);
      console.log('  ✓ ' + path + ' (refactored to <Hero />)');
    } else {
      console.log('  ⚠️  ' + path + ' — hero block not found, skipped');
    }
  "
}

patch_screen_to_hero "src/screens/AnalyzeScreen.jsx"     "hero-analyze"  "both"
patch_screen_to_hero "src/screens/PersonalityScreen.jsx" "hero-profile"  "both"
patch_screen_to_hero "src/screens/CoachScreen.jsx"       "hero-coach"    "left"
patch_screen_to_hero "src/screens/SimulateScreen.jsx"    "hero-simulate" "right"
patch_screen_to_hero "src/screens/ProfileScreen.jsx"     "hero-profile"  "both"

rm -rf .tmp-livinghero
echo ""

# Verify
MISSING=0
for f in \
  "src/components/HeroCanvas.jsx" \
  "src/components/Hero.jsx"; do
  [ ! -f "$f" ] && echo "  ❌ Missing: $f" && MISSING=1
done
[ $MISSING -eq 1 ] && exit 1
echo "✓ All files in place"
echo ""

# Git
if [ -d ".git" ]; then
  git status --short
  echo ""
  read -p "Commit and push? (y/n): " -n 1 -r
  echo ""
  if [[ $REPLY =~ ^[Yy]$ ]]; then
    git add .
    git commit -m "Living hero: canvas overlay with sparks, particles, Ken Burns drift, scan reveal"
    git push origin "$(git branch --show-current)"
    echo "✅ Pushed! Vercel is building."
  fi
fi

echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║              WHAT USERS WILL FEEL                  ║"
echo "╠═══════════════════════════════════════════════════╣"
echo "║                                                     ║"
echo "║  On mount:                                          ║"
echo "║  • Image fades in from blur + brightness darkening ║"
echo "║  • Soft scan line sweeps top→bottom (1.6s)         ║"
echo "║  • Title text slides up after image lands          ║"
echo "║                                                     ║"
echo "║  Always breathing:                                  ║"
echo "║  • Image slowly drifts (Ken Burns, 18s loop)       ║"
echo "║  • Particles float + glow with breathing pulse     ║"
echo "║  • Both brains have breathing aura                 ║"
echo "║                                                     ║"
echo "║  Periodic sparks:                                   ║"
echo "║  • Synaptic bolts arc between the two brains       ║"
echo "║  • Leave a glowing curved trail                    ║"
echo "║  • Blue→orange→blue, emotional back-and-forth      ║"
echo "║                                                     ║"
echo "║  Connection beam:                                   ║"
echo "║  • Rhythmic pulse every 3s between both brains     ║"
echo "║  • Goes blue → purple center → orange              ║"
echo "║                                                     ║"
echo "║  Performance:                                       ║"
echo "║  • Pure canvas, ~60fps, no libraries               ║"
echo "║  • ~5KB extra JS, negligible battery impact        ║"
echo "║  • Respects prefers-reduced-motion                 ║"
echo "║                                                     ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""
echo "Backup: $BACKUP"
echo ""
