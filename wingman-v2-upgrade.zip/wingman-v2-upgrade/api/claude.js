// api/claude.js
// Streaming-capable Claude proxy with retry logic and vision support.

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-5";

const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "http://localhost:5173,http://localhost:5174")
  .split(",").map((s) => s.trim()).filter(Boolean);

const ALLOWED_SYSTEM_PREFIXES = [
  "You are an elite dating coach",
  "You are a behavioral psychologist",
  "You are an expert dating coach",
  "You are a conversation scoring expert",
  "You are a dating conversation analyst",
  "You are Sofia",
  "You are Mia",
  "You are Alex",
  "You are Lily",
];

function isAllowedSystem(system) {
  if (!system || typeof system !== "string") return false;
  return ALLOWED_SYSTEM_PREFIXES.some((p) => system.startsWith(p));
}

function setCors(req, res) {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Max-Age", "86400");
}

// Per-IP rate limiter
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = 30;
const ipBuckets = new Map();

function rateLimit(req) {
  const ip =
    req.headers["x-forwarded-for"]?.split(",")[0]?.trim() ||
    req.socket?.remoteAddress || "unknown";
  const now = Date.now();
  const bucket = ipBuckets.get(ip) || { count: 0, resetAt: now + RATE_WINDOW_MS };
  if (now > bucket.resetAt) {
    bucket.count = 0;
    bucket.resetAt = now + RATE_WINDOW_MS;
  }
  bucket.count += 1;
  ipBuckets.set(ip, bucket);
  return bucket.count <= RATE_MAX;
}

async function callAnthropic(body, { stream = false } = {}) {
  const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;
  return fetch(ANTHROPIC_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ ...body, stream }),
  });
}

export default async function handler(req, res) {
  setCors(req, res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const origin = req.headers.origin;
  if (origin && !ALLOWED_ORIGINS.includes(origin)) {
    return res.status(403).json({ error: "Origin not allowed" });
  }

  if (!rateLimit(req)) {
    return res.status(429).json({ error: "Too many requests. Try again in a minute." });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: "API key not configured on server." });
  }

  const { system, userMessage, maxTokens, image, stream } = req.body || {};

  if (!system || !isAllowedSystem(system)) {
    return res.status(400).json({ error: "Invalid system prompt." });
  }
  if (!userMessage || typeof userMessage !== "string") {
    return res.status(400).json({ error: "Missing userMessage." });
  }

  const tokens = Math.min(Math.max(Number(maxTokens) || 800, 50), 1500);

  let messageContent;
  if (image && image.data && image.mediaType) {
    const validTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    if (!validTypes.includes(image.mediaType)) {
      return res.status(400).json({ error: "Unsupported image type." });
    }
    if (image.data.length > 7_000_000) {
      return res.status(400).json({ error: "Image too large (max ~5MB)." });
    }
    messageContent = [
      { type: "image", source: { type: "base64", media_type: image.mediaType, data: image.data } },
      { type: "text", text: userMessage },
    ];
  } else {
    messageContent = userMessage;
  }

  const body = {
    model: MODEL,
    max_tokens: tokens,
    system,
    messages: [{ role: "user", content: messageContent }],
  };

  // ── STREAMING MODE ──
  if (stream === true) {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");

    try {
      const upstream = await callAnthropic(body, { stream: true });
      if (!upstream.ok || !upstream.body) {
        const err = await upstream.json().catch(() => ({}));
        res.write(`data: ${JSON.stringify({ error: err?.error?.message || "Upstream error" })}\n\n`);
        return res.end();
      }

      const reader = upstream.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6);
          try {
            const event = JSON.parse(jsonStr);
            if (event.type === "content_block_delta" && event.delta?.type === "text_delta") {
              res.write(`data: ${JSON.stringify({ text: event.delta.text })}\n\n`);
            } else if (event.type === "message_stop") {
              res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
            }
          } catch {}
        }
      }
      res.end();
    } catch (err) {
      res.write(`data: ${JSON.stringify({ error: "Stream failed" })}\n\n`);
      res.end();
    }
    return;
  }

  // ── NON-STREAMING WITH RETRY ──
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const response = await callAnthropic(body);
      if (response.ok) {
        const data = await response.json();
        return res.status(200).json({ text: data.content?.[0]?.text ?? "" });
      }
      // Retry on 5xx or 429 only
      if (response.status < 500 && response.status !== 429) {
        const err = await response.json().catch(() => ({}));
        return res.status(response.status).json({
          error: err?.error?.message || `API error ${response.status}`,
        });
      }
      lastError = `${response.status}`;
    } catch (err) {
      lastError = err.message;
    }
    if (attempt === 0) await new Promise((r) => setTimeout(r, 800));
  }
  return res.status(502).json({ error: `AI service unavailable (${lastError})` });
}
