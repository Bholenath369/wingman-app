# Wingman v2 — Effectiveness Upgrade

This patch makes your app **noticeably smarter and more retentive** without requiring
auth/database. All changes are drop-in replacements or new files.

## What's new

### 1. Two-step smart analysis (massive quality jump)
The AI now:
- **First** classifies the conversation: stage, temperature, main risk, their emotional state
- **Then** generates replies tuned to that specific situation

You'll see a small context card above replies showing "Early chat · warm vibe · they feel flirty curious"
and a "Watch out: avoid coming on too strong" warning when relevant.

**Cost:** ~$0.002 extra per analysis. Quality increase is dramatic.

### 2. Send-to-app deep links
Every reply now has direct buttons for WhatsApp / iMessage / Instagram / Telegram / native share.
Users no longer have to copy-paste-app-switch. This alone will 2x retention.

### 3. Streaming persona replies
In the Simulate screen, the persona's reply now appears word-by-word as Claude generates it,
with a blinking cursor. Feels 10x faster even though total latency is identical.

### 4. Onboarding vibe capture
First-time users see a quick 2-tap modal:
- "What's your style?" (witty, warm, confident, etc.)
- "What usually goes wrong?" (too strong, too shy, overthink, etc.)

Stored in localStorage, automatically prepended to every AI prompt.
Result: the AI's output actually sounds like the user, not a generic script.

### 5. Thumbs up/down feedback
Each reply card now has 👍 / 👎 buttons. Thumbs down triggers regeneration
that actively avoids that style. A note shows "✓ Avoiding: flirty, emotional"
so the user sees the AI learning.

### 6. Automatic retry on flaky connections
Every API call now retries once on 5xx/429/network errors with a 1.2s delay.
Users stop seeing scary red errors for transient blips.

---

## Files in this bundle

```
api/claude.js                          ← REPLACE (adds streaming + retry)
src/App.jsx                            ← REPLACE (adds onboarding trigger)
src/lib/claude.js                      ← REPLACE (two-step, vibe, streaming)
src/lib/deepLinks.js                   ← NEW
src/components/SendToApp.jsx           ← NEW
src/components/OnboardingModal.jsx     ← NEW
src/screens/AnalyzeScreen.jsx          ← REPLACE (context card, thumbs, send-to-app)
src/screens/SimulateScreen.jsx         ← REPLACE (streaming bubbles)
src/index-additions.css                ← APPEND to src/index.css
```

**Files NOT changing** (keep your existing versions):
- `src/screens/CoachScreen.jsx`, `PersonalityScreen.jsx`, `ProfileScreen.jsx`
- `src/components/PremiumGate.jsx`
- `src/lib/useUsage.js`
- `api/usage.js`, `create-checkout.js`, `stripe-webhook.js`, `upgrade-redeem.js`
- `vercel.json`, `.env.example`, `package.json`

---

## How to apply

### Option 1: Automated (recommended)

Put both `wingman-v2-upgrade.zip` and `apply-v2.sh` in your project root, then:

```bash
bash apply-v2.sh
```

### Option 2: Manual copy

1. Unzip `wingman-v2-upgrade.zip`
2. Copy each file to its destination path (see list above)
3. **Important:** Append the contents of `src/index-additions.css` to the END of
   your existing `src/index.css` file (do NOT replace the whole CSS file)
4. Commit & push

---

## Env vars

**No new env vars needed.** This upgrade uses everything already configured
from the previous version (ANTHROPIC_API_KEY, ALLOWED_ORIGINS, etc.)

---

## Testing checklist

After deploying:

- [ ] Open your app in an incognito window. Onboarding modal should appear after ~1 second.
- [ ] Complete onboarding (pick any style + struggle). Modal should close.
- [ ] Analyze a screenshot. You should see:
  - A context card with stage/temperature/feeling chips
  - 4 reply cards
  - Send-to-app buttons under each (WhatsApp, iMessage on iOS, Instagram, etc.)
  - 👍/👎 buttons on the right of each card
- [ ] Click 👎 on one reply. It should regenerate with a note "Avoiding: [type]" below.
- [ ] Go to Simulate. Send a message. The reply should appear word-by-word with a cursor.
- [ ] Refresh. Onboarding should NOT show again (persisted in localStorage).

---

## Known tradeoffs

**Onboarding is per-browser.** Since we're not using auth, a user who clears localStorage
or switches devices will see onboarding again. Fine for now. When you add Supabase auth,
move this to the user profile.

**Vibe data is client-side only.** Currently stored in localStorage and sent with every
request. Works perfectly but has the same cross-device limitation.

**Instagram deep link still requires a copy step.** Instagram doesn't support URL-prefilled
messages — there's no workaround. We auto-copy and open the app as best-effort.

**Streaming only works where SSE is supported.** All modern browsers support it.
If you ever deploy to a platform that buffers responses (some CDNs), you may need to
disable streaming — the non-streaming `simulateReply` is still available as a fallback.

---

## What this WON'T fix

- Users who don't enjoy the core output quality. The AI is now much better tuned,
  but if your demo convo is too staged or the prompts don't match real usage, you'll
  still see churn. Watch actual user conversations (ask for opt-in feedback).
- Users without a use case. This is still a tool for people actively dating.
  If your traffic is curiosity-driven, conversion will stay low regardless.
- Discoverability. This is a product improvement, not a marketing one.
