// src/components/OnboardingModal.jsx
import { useState } from "react";
import { setUserVibe } from "../lib/claude";

const STYLE_OPTIONS = [
  "witty and sarcastic",
  "warm and genuine",
  "cool and mysterious",
  "playful and flirty",
  "direct and confident",
  "thoughtful and deep",
];

const STRUGGLE_OPTIONS = [
  "I come on too strong",
  "I get too shy or boring",
  "I overthink every message",
  "Conversations die after a few texts",
  "I can't get past small talk",
  "I never know when to escalate",
];

export default function OnboardingModal({ onComplete }) {
  const [step, setStep] = useState(0);
  const [style, setStyle] = useState(null);
  const [struggle, setStruggle] = useState(null);

  function finish() {
    setUserVibe({ style, struggle });
    onComplete?.();
  }

  function skip() {
    setUserVibe({ skipped: true });
    onComplete?.();
  }

  return (
    <div style={overlayStyle}>
      <div style={modalStyle}>
        <button onClick={skip} style={skipStyle}>Skip</button>

        {step === 0 && (
          <>
            <div style={{ fontSize: 38, marginBottom: 12 }}>👋</div>
            <h2 style={titleStyle}>Quick question</h2>
            <p style={subtitleStyle}>
              Two taps and your AI wingman knows exactly how to sound like you.
            </p>
            <button onClick={() => setStep(1)} style={primaryBtn}>
              Let's go →
            </button>
          </>
        )}

        {step === 1 && (
          <>
            <div style={stepDot}>1 of 2</div>
            <h2 style={titleStyle}>What's your style?</h2>
            <p style={subtitleStyle}>Pick the vibe closest to how you actually text.</p>
            <div style={optionsGrid}>
              {STYLE_OPTIONS.map((opt) => (
                <button
                  key={opt}
                  onClick={() => { setStyle(opt); setTimeout(() => setStep(2), 120); }}
                  style={{
                    ...optionBtn,
                    ...(style === opt ? optionBtnActive : {}),
                  }}
                >
                  {opt}
                </button>
              ))}
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <div style={stepDot}>2 of 2</div>
            <h2 style={titleStyle}>What usually goes wrong?</h2>
            <p style={subtitleStyle}>So the AI knows what to help you fix.</p>
            <div style={optionsGrid}>
              {STRUGGLE_OPTIONS.map((opt) => (
                <button
                  key={opt}
                  onClick={() => { setStruggle(opt); setTimeout(finish, 120); }}
                  style={{
                    ...optionBtn,
                    ...(struggle === opt ? optionBtnActive : {}),
                  }}
                >
                  {opt}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

const overlayStyle = {
  position: "fixed",
  inset: 0,
  background: "rgba(10,5,20,0.85)",
  backdropFilter: "blur(8px)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 9999,
  padding: 16,
  animation: "fadeIn .3s ease",
};

const modalStyle = {
  background: "linear-gradient(145deg, #1E0A1A 0%, #0D0420 100%)",
  border: "0.5px solid rgba(232,84,122,0.35)",
  borderRadius: 20,
  padding: "32px 24px 28px",
  maxWidth: 400,
  width: "100%",
  textAlign: "center",
  position: "relative",
  boxShadow: "0 20px 60px rgba(0,0,0,0.5), 0 0 40px rgba(232,84,122,0.15)",
  animation: "slideUp .35s ease",
};

const skipStyle = {
  position: "absolute",
  top: 14,
  right: 16,
  fontSize: 11,
  color: "rgba(255,255,255,0.4)",
  background: "none",
  border: "none",
  cursor: "pointer",
  padding: 6,
};

const titleStyle = {
  fontFamily: "var(--font-display)",
  fontSize: 24,
  color: "#fff",
  marginBottom: 8,
  lineHeight: 1.15,
};

const subtitleStyle = {
  fontSize: 13,
  color: "rgba(255,255,255,0.55)",
  lineHeight: 1.5,
  marginBottom: 20,
};

const primaryBtn = {
  width: "100%",
  padding: 14,
  borderRadius: 12,
  background: "linear-gradient(135deg, #E8547A, #C43060)",
  border: "none",
  color: "#fff",
  fontSize: 14,
  fontWeight: 600,
  cursor: "pointer",
  boxShadow: "0 4px 20px rgba(232,84,122,0.35)",
};

const stepDot = {
  fontSize: 10,
  fontWeight: 600,
  letterSpacing: "0.6px",
  textTransform: "uppercase",
  color: "rgba(232,84,122,0.8)",
  marginBottom: 10,
};

const optionsGrid = {
  display: "flex",
  flexDirection: "column",
  gap: 8,
};

const optionBtn = {
  padding: "12px 14px",
  borderRadius: 10,
  background: "rgba(255,255,255,0.04)",
  border: "0.5px solid rgba(255,255,255,0.12)",
  color: "var(--text)",
  fontSize: 13,
  fontWeight: 500,
  cursor: "pointer",
  textAlign: "left",
  transition: "all .15s",
};

const optionBtnActive = {
  background: "rgba(232,84,122,0.15)",
  borderColor: "var(--accent)",
  color: "var(--accent)",
};
