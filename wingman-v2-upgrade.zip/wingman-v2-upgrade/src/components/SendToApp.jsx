// src/components/SendToApp.jsx
import { useState } from "react";
import { getAvailableApps, nativeShare } from "../lib/deepLinks";

export default function SendToApp({ text, compact = false }) {
  const [toast, setToast] = useState("");
  const apps = getAvailableApps();

  async function handleClick(app) {
    try {
      if (app.key === "share") {
        const result = await nativeShare(text);
        if (result.method === "clipboard") setToast("Copied to clipboard");
        else if (result.method === "native") setToast("Shared!");
      } else if (app.key === "instagram") {
        await app.handler(text);
        setToast("Copied — opening Instagram...");
      } else {
        app.handler(text);
        setToast(`Opening ${app.label}...`);
      }
      setTimeout(() => setToast(""), 2500);
    } catch {
      setToast("Something went wrong");
      setTimeout(() => setToast(""), 2000);
    }
  }

  if (compact) {
    // Single native-share button (for tight spaces)
    return (
      <>
        <button
          onClick={() => handleClick(apps[0])}
          style={{
            fontSize: 11,
            fontWeight: 500,
            color: "var(--accent)",
            background: "none",
            border: "none",
            padding: 0,
            marginTop: 6,
          }}
        >
          📤 Send ↗
        </button>
        {toast && <div style={toastStyle}>{toast}</div>}
      </>
    );
  }

  return (
    <>
      <div style={{
        display: "flex",
        gap: 6,
        flexWrap: "wrap",
        marginTop: 10,
      }}>
        {apps.map((app) => (
          <button
            key={app.key}
            onClick={() => handleClick(app)}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 5,
              padding: "6px 11px",
              borderRadius: 16,
              fontSize: 11,
              fontWeight: 500,
              background: "var(--bg3)",
              border: "0.5px solid var(--border2)",
              color: "var(--text)",
              cursor: "pointer",
              transition: "all .15s",
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.borderColor = "var(--accent)";
              e.currentTarget.style.color = "var(--accent)";
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.borderColor = "var(--border2)";
              e.currentTarget.style.color = "var(--text)";
            }}
          >
            <span>{app.emoji}</span>
            <span>{app.label}</span>
          </button>
        ))}
      </div>
      {toast && <div style={toastStyle}>{toast}</div>}
    </>
  );
}

const toastStyle = {
  position: "fixed",
  bottom: 90,
  left: "50%",
  transform: "translateX(-50%)",
  background: "rgba(20, 15, 30, 0.95)",
  border: "0.5px solid var(--accent)",
  color: "var(--text)",
  padding: "10px 18px",
  borderRadius: 20,
  fontSize: 12,
  fontWeight: 500,
  zIndex: 1000,
  backdropFilter: "blur(10px)",
  animation: "slideUp .25s ease",
};
