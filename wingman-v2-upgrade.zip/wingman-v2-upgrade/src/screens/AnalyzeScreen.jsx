import { useState, useRef } from "react";
import {
  analyzeScreenshotSmart,
  analyzeScreenshotImageSmart,
} from "../lib/claude";
import { useUsage } from "../lib/useUsage";
import PremiumGate from "../components/PremiumGate";
import SendToApp from "../components/SendToApp";

const DEMO_CONVO = `Her: A million random thoughts, but talking to you is definitely the nicest one right now 🌙
Her: worth it if it means you're thinking about me too`;

const STAGE_LABELS = {
  first_message: "First message",
  early_chat: "Early chat",
  building_rapport: "Building rapport",
  dying_conversation: "Fading out",
  post_date: "After the date",
};

const TEMP_COLORS = {
  cold: "#60A5FA",
  cool: "#22D3EE",
  warm: "#FBBF24",
  hot: "#F43F5E",
};

export default function AnalyzeScreen() {
  const [stage, setStage]         = useState("upload"); // upload | typing | replies
  const [replies, setReplies]     = useState([]);
  const [context, setContext]     = useState(null);
  const [copied, setCopied]       = useState(null);
  const [convoText, setConvoText] = useState("");
  const [submittedText, setSubmittedText] = useState("");
  const [previewImage, setPreviewImage]   = useState(null);
  const [error, setError]         = useState("");
  const [rejectedStyles, setRejectedStyles] = useState([]);
  const [currentSource, setCurrentSource]   = useState(null); // "text" | "image"
  const [currentFile, setCurrentFile]       = useState(null);
  const fileRef = useRef();
  const { consume, remaining, isPremium, loading: usageLoading } = useUsage();

  function parseConvoBubbles(text) {
    return text.split("\n").filter(Boolean).map((line) => {
      const match = line.match(/^(Her|Me|Him|Them|You):\s*(.+)/i);
      if (match) return {
        side: match[1].toLowerCase() === "me" || match[1].toLowerCase() === "you" ? "you" : "them",
        text: match[2],
      };
      return { side: "them", text: line };
    });
  }

  async function runAnalysis({ text = null, file = null, avoid = [] }) {
    const check = await consume("analyze");
    if (!check.allowed) {
      setError("Daily limit reached. Upgrade to Premium for unlimited.");
      return;
    }

    setError("");
    setStage("typing");

    if (text) {
      setSubmittedText(text);
      setPreviewImage(null);
      setCurrentSource("text");
    } else if (file) {
      const previewUrl = URL.createObjectURL(file);
      setPreviewImage(previewUrl);
      setSubmittedText("");
      setCurrentSource("image");
      setCurrentFile(file);
    }

    try {
      const result = text
        ? await analyzeScreenshotSmart(text, { avoidStyles: avoid })
        : await analyzeScreenshotImageSmart(file, { avoidStyles: avoid });
      setContext(result.context);
      setReplies(result.replies);
      setStage("replies");
    } catch (e) {
      setError(e.message || "Analysis failed. Try again.");
      setStage("upload");
    }
  }

  async function regenerateAvoiding(style) {
    const newAvoid = [...rejectedStyles, style];
    setRejectedStyles(newAvoid);

    if (currentSource === "text") {
      await runAnalysis({ text: submittedText, avoid: newAvoid });
    } else if (currentSource === "image" && currentFile) {
      await runAnalysis({ file: currentFile, avoid: newAvoid });
    }
  }

  function handleFileChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setError("Image too large. Max 5MB.");
      return;
    }
    setRejectedStyles([]);
    runAnalysis({ file });
  }

  function copyReply(text, idx) {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(idx);
    setTimeout(() => setCopied(null), 2000);
  }

  function reset() {
    if (previewImage) URL.revokeObjectURL(previewImage);
    setStage("upload");
    setReplies([]);
    setContext(null);
    setConvoText("");
    setSubmittedText("");
    setPreviewImage(null);
    setCurrentFile(null);
    setCurrentSource(null);
    setRejectedStyles([]);
    setError("");
  }

  const TAG_COLORS = {
    flirty: "#E8547A", funny: "#F59E0B",
    confident: "#7C5CFC", emotional: "#22C55E",
  };

  const analyzeRemaining = remaining?.analyze ?? 0;
  const atLimit = !usageLoading && !isPremium && analyzeRemaining === 0;

  return (
    <div>
      <div className="hero hero-with-image">
        <img className="hero-img" src="/images/hero-analyze.svg" alt="" aria-hidden="true" />
        <div className="hero-content">
          <div className="hero-eyebrow">✦ AI Wingman</div>
          <h2>Get the perfect reply</h2>
          <p>Upload any chat screenshot — we'll read the room and write your best move.</p>
        </div>
      </div>

      {error && (
        <div style={errorStyle}>{error}</div>
      )}

      {stage === "upload" && !atLimit && (
        <>
          <button className="upload-area" onClick={() => fileRef.current.click()}>
            <div className="upload-icon">📱</div>
            <h3>Drop your screenshot here</h3>
            <p>WhatsApp · Tinder · Instagram · iMessage</p>
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            style={{ display: "none" }}
            onChange={handleFileChange}
          />

          <div className="section-label">Or paste conversation text</div>
          <textarea
            className="coach-textarea"
            placeholder="Paste chat messages here..."
            value={convoText}
            onChange={(e) => setConvoText(e.target.value)}
            style={{ height: 100, marginBottom: 10 }}
          />
          <button
            className="btn-primary"
            style={{
              width: "100%",
              padding: 13,
              borderRadius: 10,
              opacity: convoText.trim().length < 5 ? .4 : 1,
            }}
            disabled={convoText.trim().length < 5}
            onClick={() => { setRejectedStyles([]); runAnalysis({ text: convoText }); }}
          >
            Analyze conversation →
          </button>

          <div style={{ textAlign: "center", marginTop: 14 }}>
            <button
              onClick={() => { setRejectedStyles([]); runAnalysis({ text: DEMO_CONVO }); }}
              style={{ fontSize: 12, color: "var(--accent)", background: "none", border: "none" }}
            >
              Try with demo conversation
            </button>
          </div>

          {!isPremium && !usageLoading && (
            <div style={{ textAlign: "center", marginTop: 14, fontSize: 12, color: "var(--text3)" }}>
              {analyzeRemaining} free analyses remaining today
            </div>
          )}
        </>
      )}

      {atLimit && (
        <PremiumGate
          title="Daily limit reached"
          description="Upgrade for unlimited screenshot analyses, all 4 personas, and deep personality insights."
          features={[
            "Unlimited screenshot analyses",
            "All 4 practice personas with scoring",
            "Profile photo analyzer",
            "Bio rewriter",
            "Full personality breakdowns",
          ]}
        />
      )}

      {stage === "typing" && (
        <>
          {previewImage ? (
            <div style={previewBoxStyle}>
              <img src={previewImage} alt="Your screenshot" style={{ width: "100%", display: "block" }} />
            </div>
          ) : (
            <div className="chat-preview">
              {parseConvoBubbles(submittedText).map((b, i) => (
                <div key={i} className={`bubble bubble-${b.side}`}>{b.text}</div>
              ))}
            </div>
          )}
          <div className="typing-wrap">
            <div className="typing-indicator">
              <div className="dot" /><div className="dot" /><div className="dot" />
            </div>
            <span style={{ fontSize: 12, color: "var(--text2)" }}>
              Reading context, then generating replies...
            </span>
          </div>
        </>
      )}

      {stage === "replies" && (
        <>
          {previewImage ? (
            <div style={previewBoxStyle}>
              <img src={previewImage} alt="Your screenshot" style={{ width: "100%", display: "block" }} />
            </div>
          ) : (
            <div className="chat-preview">
              {parseConvoBubbles(submittedText).map((b, i) => (
                <div key={i} className={`bubble bubble-${b.side}`}>{b.text}</div>
              ))}
            </div>
          )}

          {/* CONTEXT CARD — shows the AI's read of the situation */}
          {context && (
            <div style={contextCardStyle}>
              <div style={contextRowStyle}>
                <div style={{ ...contextChip, background: "rgba(232,84,122,0.12)", color: "#F08090" }}>
                  {STAGE_LABELS[context.stage] || context.stage}
                </div>
                <div style={{
                  ...contextChip,
                  background: `${TEMP_COLORS[context.temperature]}22`,
                  color: TEMP_COLORS[context.temperature],
                }}>
                  {context.temperature} vibe
                </div>
                <div style={{ ...contextChip, background: "rgba(124,92,252,0.12)", color: "#9B87F5" }}>
                  They feel {context.theyFeeling}
                </div>
              </div>
              {context.risk && (
                <div style={contextRiskStyle}>
                  <strong style={{ color: "#FBBF24" }}>⚠ Watch out:</strong> avoid {context.risk.replace(/_/g, " ")}
                </div>
              )}
            </div>
          )}

          <div className="section-label">AI reply suggestions</div>
          <div className="reply-stack">
            {replies.map((r, i) => (
              <div key={i} className={`reply-card ${i === 0 ? "best-match" : ""}`}>
                {i === 0 && <span className="best-badge">Best match</span>}
                <div className="reply-tag" style={{ color: TAG_COLORS[r.type] || "var(--accent)" }}>
                  {r.emoji} {r.type}
                </div>
                <div className="reply-text">{r.text}</div>

                {/* Send to messaging apps */}
                <SendToApp text={r.text} />

                <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 10 }}>
                  <button className="copy-btn" onClick={() => copyReply(r.text, i)}>
                    {copied === i ? "Copied!" : "Copy ↗"}
                  </button>

                  {/* Thumbs feedback */}
                  <div style={{ marginLeft: "auto", display: "flex", gap: 4 }}>
                    <button
                      onClick={() => {
                        // Thumbs up = just visual feedback, no regen
                        const el = document.getElementById(`thumb-up-${i}`);
                        if (el) { el.style.color = "#22C55E"; el.style.transform = "scale(1.2)"; }
                      }}
                      id={`thumb-up-${i}`}
                      style={thumbBtn}
                      title="Good suggestion"
                    >
                      👍
                    </button>
                    <button
                      onClick={() => regenerateAvoiding(r.type)}
                      style={thumbBtn}
                      title={`Generate new replies — avoid ${r.type} style`}
                    >
                      👎
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {rejectedStyles.length > 0 && (
            <div style={rejectedNoteStyle}>
              ✓ Avoiding: {rejectedStyles.join(", ")}
            </div>
          )}

          <div className="share-hook">
            <p>"This AI fixed my dating life" — share your best reply</p>
            <button onClick={() => {
              const text = "Check out AI Dating Wingman — it writes your best replies ✨";
              if (navigator.share) { navigator.share({ title: "AI Wingman", text }).catch(() => {}); }
              else { navigator.clipboard.writeText(text).catch(() => {}); }
            }}>Share ↗</button>
          </div>

          <button className="reset-btn" onClick={reset}>← Analyze another screenshot</button>
        </>
      )}
    </div>
  );
}

// ── Styles ──
const errorStyle = {
  background: "rgba(239,68,68,0.1)",
  border: "0.5px solid rgba(239,68,68,0.3)",
  borderRadius: 10,
  padding: "10px 14px",
  marginBottom: 14,
  fontSize: 13,
  color: "#FCA5A5",
};

const previewBoxStyle = {
  marginBottom: 14,
  borderRadius: 12,
  overflow: "hidden",
  border: "0.5px solid var(--border)",
  maxHeight: 340,
};

const contextCardStyle = {
  background: "linear-gradient(135deg, rgba(232,84,122,0.06), rgba(124,92,252,0.06))",
  border: "0.5px solid rgba(232,84,122,0.18)",
  borderRadius: 12,
  padding: "12px 14px",
  marginBottom: 14,
  animation: "fadeScale .3s ease",
};

const contextRowStyle = {
  display: "flex",
  flexWrap: "wrap",
  gap: 6,
};

const contextChip = {
  padding: "4px 10px",
  borderRadius: 20,
  fontSize: 10,
  fontWeight: 600,
  letterSpacing: "0.3px",
  textTransform: "capitalize",
};

const contextRiskStyle = {
  marginTop: 8,
  fontSize: 11,
  color: "rgba(255,255,255,0.6)",
  lineHeight: 1.4,
};

const thumbBtn = {
  background: "none",
  border: "none",
  fontSize: 14,
  cursor: "pointer",
  padding: "4px 6px",
  borderRadius: 6,
  transition: "transform .15s",
};

const rejectedNoteStyle = {
  textAlign: "center",
  marginTop: 12,
  fontSize: 11,
  color: "var(--text3)",
  fontStyle: "italic",
};
